/* Elum.h - Elum class to allow access to single Elums

Copyright (c) 2012 David Michael Betz

Permission is hereby granted, free of charge, to any person obtaining a copy of this software
and associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or
substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/

#include <stdint.h>
#include <propeller.h>


static inline int32_t Min__(int32_t a, int32_t b)
{
    return a < b ? a : b;
}
static inline int32_t Max__(int32_t a, int32_t b)
{
    return a > b ? a : b;
}


class Elum
{
private:
//    uint32_t r_mask;
//    uint32_t g_mask;
    int32_t pin_r;
    int32_t pin_g;
    int32_t _clockfreq;
    uint32_t b_mask;
    int32_t Fraction(int32_t Y, int32_t X, int32_t B);
    int32_t Pwm(int32_t Pin, int32_t Period_ms, int32_t Flash_ms);

public:
    Elum(int32_t RedPin, int32_t GreenPin, int32_t ButtonPin);
    ~Elum();
    int32_t getButton();
    int32_t Slowclock(void);
    int32_t On(int32_t whichcolor);
    int32_t Off();
    void Flash(int32_t Whichpin, int32_t Period_ms, int32_t Flash_ms);

    enum {RED = 0, GREEN = 1};

};

inline Elum::Elum(int32_t RedPin, int32_t GreenPin, int32_t ButtonPin) : b_mask(1 << ButtonPin)
{
    DIRA &= ~b_mask; //Set button to input

    pin_r = RedPin;
    pin_g = GreenPin;

    DIRA |= (1 << pin_r);
    DIRA |= (1 << pin_g);

    _clockfreq = CLKFREQ;
}

inline Elum::~Elum()
{
}


inline int32_t Elum::getButton()
{
    return (INA & b_mask) == 0;
}

void Elum::Flash(int32_t Whichpin, int32_t Period_ms, int32_t Flash_ms)
{
    CTRA = (CTRB = 0); //Stop counters while updating

    if (Whichpin == RED)
    {
        OUTA |= 1 << pin_g; //Make second pin high
        Pwm(pin_r, Period_ms, Flash_ms);
    }
    else if(Whichpin == GREEN)
    {
        OUTA |= 1 << pin_r; //Make second pin high
        Pwm(pin_g, Period_ms, Flash_ms);

    }
}

int32_t Elum::Slowclock(void)
{
    int32_t result = 0;
    _clockfreq = 20000;
    return result;
}

inline int32_t Elum::On(int32_t whichColor)
{
    int32_t result = 0;

    CTRA = (CTRB = 0);
    if(whichColor == RED)
    {
        OUTA |= (1<<pin_g);
        OUTA &= ~(1<<pin_r);
    }
    else
    {
        OUTA &= ~(1<<pin_g);
        OUTA |= (1<<pin_r);
    }
    return result;
}

int32_t Elum::Off(void)
{
    int32_t result = 0;
    OUTA &= ~(1 << pin_r);
    OUTA &= ~(1 << pin_g);
    CTRA = (CTRB = 0);
    return result;
}

int32_t Elum::Pwm(int32_t Pin, int32_t Period_ms, int32_t Flash_ms)
{
    int32_t	Phsx, Frqx;
    int32_t result = 0;
    FRQA = (FRQB = 0);
    Flash_ms = ((Period_ms / 2) - (Min__(Flash_ms, (Period_ms / 2))));
    Phsx = Fraction(Flash_ms, Period_ms, 32);
    Frqx = Fraction(1, ((_clockfreq / 1000) * Period_ms), 32);
    PHSB = (PHSA + Phsx);
    FRQA = (FRQB = Frqx);
    _clockfreq = CLKFREQ;
    OUTA &= ~(1<<Pin);
    CTRA = (0x10000000 + Pin);
    CTRB = (0x10000000 + Pin);
    return Phsx;
}

int32_t Elum::Fraction(int32_t Y, int32_t X, int32_t B)
{
    int32_t F = 0;
    {
        int32_t _idx__0000;
        _idx__0000 = B;
        do
        {
            Y = (Y << 1);
            F = (F << 1);
            if (Y >= X)
            {
                Y = (Y - X);
                (F++);
            }
            _idx__0000 = (_idx__0000 + -1);
        }
        while (_idx__0000 >= 1);
    }
    return F;
}


