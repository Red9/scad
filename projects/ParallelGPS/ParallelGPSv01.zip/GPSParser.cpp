/**
 * @file
 * @Author Cody Lewis (srlm@srlmproductions.com)
 * @date   (DATE)
 * @brief  (BRIEF)
 *
 * DETAILED DESCRIPTION
 */

#include "GPSParser.h"

GPSParser::GPSParser(int32_t Rx_pin, int32_t Tx_pin, int32_t Rate)
{
    head = 0;
    gps.Start(Rx_pin, Tx_pin, Rate);
}

//int32_t GPSParser::Rx()
//{
//    return gps.Rx();
//}

int32_t GPSParser::GetStr()
{
    for(;;)
    {
        int32_t byte = gps.Rxcheck();
        if(byte == -1) return -1;

        //Have a valid byte, now need to add to buffer
        buffer[head++] = byte;

        //Check if it's the end of a string.
        if (byte == '\n')
        {
            buffer[head] = 0; //Null terminator
            head = 0;         //Reset head
            return &buffer;   //Return pointer
        }
    }
}
