#ifndef GPSPARSER_H_INCLUDED
#define GPSPARSER_H_INCLUDED

#include <stdint.h>
#include "FFDS1.h"

class GPSParser
{
    public:
        GPSParser(int32_t Rx_pin, int32_t Tx_pin, int32_t Baud);
//        void Setbaud(int32_t Rate);

        /** Gets a NMEA string. Note that the returned string address is
         *  valid (will not be overwritten) until the next time GetStr()
         *  is called.
         * @returns -1 if no string, null terminated string otherwise
         */
        int32_t GetStr();
//        int32_t Rx();

    private:
        FFDS1 gps;
        int32_t head;
        uint8_t buffer[85]; //Holds 1 NMEA string
};



#endif // GPSPARSER_H_INCLUDED
